function getMovie(movieId){
     window.location.href="/m/"+movieId;
 }

 function getTv(TvId){
     window.location.href="/t/"+TvId;

 }

 function goToProfile() {
     window.location.href="/me";
 }

function getVideos(){
     window.location.href="/v/all";
 }