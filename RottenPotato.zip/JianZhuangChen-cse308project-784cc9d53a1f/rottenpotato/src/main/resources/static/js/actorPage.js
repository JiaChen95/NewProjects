function getMovie(movieKey)
{
    window.location.href="/m/"+movieKey;
}