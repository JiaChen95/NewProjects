#Jia Chen 111118311
import re
errorFlag = 0 #0 == no syntax error
#Encapsulation fuctions for wrapping lexToken

variables = dict()

#1. For only storing data
class Node:
	def __init__(self):
		print("init node")

	def evaluate(self):
		return 0

	def execute(self):
		return 0

class NumberNode(Node):
	def __init__(self, v):
		if('.' in v):
			self.value = float(v)
		else:
			self.value = int(v)

	def evaluate(self):
		return self.value

class BoolNode(Node):
	def __init__(self, v):
		if(v == 'True'):
			self.value = True
		elif(v=='False'):
			self.value = False

	def evaluate(self):
		return self.value

class ListNode(Node):
	def __init__(self, s):
		self.list1 = [s]
		self.list2 = []
	def evaluate(self):
		for statement in self.list1:
			self.list2.append(statement.evaluate())
		return self.list2

class EmptyListNode(Node):
	def __init__(self):
		self.list1 = []

	def evaluate(self):
		return self.list1

class StringNode(Node):
	def __init__(self, v):
		self.value = str(v).replace('"','').replace("'","")

	def evaluate(self):
		return self.value

class IndexingNode(Node):
	def __init__(self, list1, index):
		self.list1 = list1
		self.index = index

	def evaluate(self):
		return self.list1.evaluate()[self.index.evaluate()]

class BooleanNode(Node):
	def __init__(self, op, v1, v2):
		self.op = op
		self.v1 = v1
		self.v2 = v2
	def evaluate(self):
		if(self.op == 'or'):
			if(isinstance(self.v1.evaluate(), bool)and isinstance(self.v2.evaluate(), bool)):
				return self.v1.evaluate() or self.v2.evaluate()
			else:
				raise TypeError
		elif(self.op == 'and'):
			if(isinstance(self.v1.evaluate(), bool)and isinstance(self.v2.evaluate(), bool)):
				return self.v1.evaluate() and self.v2.evaluate()
			else:
				raise TypeError



		elif(self.op == '<'):
			return self.v1.evaluate() < self.v2.evaluate()
		elif(self.op == '<='):
			return self.v1.evaluate() <= self.v2.evaluate()
		elif(self.op == '=='):
			return self.v1.evaluate() == self.v2.evaluate()
		elif(self.op == '<>'):
			return self.v1.evaluate() != self.v2.evaluate()
		elif(self.op == '>'):
			return self.v1.evaluate() > self.v2.evaluate()
		elif(self.op == '>='):
			return self.v1.evaluate() >= self.v2.evaluate()
		elif(self.op == 'in'):
			return self.v1.evaluate() in self.v2.evaluate()

class NotNode(Node):
	def __init__(self, v):
		self.v = v

	def evaluate(self):
		if(isinstance(self.v.evaluate(), bool)):
			return not self.v.evaluate()
		else:
			raise TypeError

class BopNode(Node):
	def __init__(self, op, v1, v2):
		self.v1 = v1
		self.v2 = v2
		self.op = op

	def evaluate(self):
		if (self.op == '+'):
			return self.v1.evaluate() + self.v2.evaluate()
		elif (self.op == '-'):
			return self.v1.evaluate() - self.v2.evaluate()

		elif (self.op == '*'):
			if( isinstance(self.v1, StringNode) or  isinstance(self.v2, StringNode) ):
				raise TypeError
			else:
				return self.v1.evaluate() * self.v2.evaluate()

		elif (self.op == '/'):
			return self.v1.evaluate() / self.v2.evaluate()
		elif (self.op == '//'):
			return self.v1.evaluate() // self.v2.evaluate()
		elif (self.op == '%'):
			return self.v1.evaluate() % self.v2.evaluate()
		
class PowerNode(Node):
	def __init__(self, v1, v2):
		self.v1 = v1
		self.v2 = v2

	def evaluate(self):
		return self.v1.evaluate() ** self.v2.evaluate()



class VariableNode(Node):
	def __init__(self, variableName):
		#the value of a variable would not change after assignment
		self.variableName = str(variableName)

	def evaluate(self):
		return variables[self.variableName] 
#########################





#2. For executing statements

class AssignmentNode(Node):
	def __init__(self, leftExpression, rightExpression):
		#the value of a variable would not change after assignment
		self.leftExpression = leftExpression
		self.rightExpression = rightExpression

	def execute(self):
		#Variable Node
		if(isinstance(self.leftExpression, VariableNode)):
			variables[self.leftExpression.variableName] = self.rightExpression.evaluate()
		#Indexing Node
		else:
			indexList = []
			#while indexingNode still contains a list, keep going inside
			while(isinstance(self.leftExpression.list1, IndexingNode)):
				#add the rightmost index to the tail of list finally
				indexList.insert(0, self.leftExpression.index.evaluate())
				#keep going inside
				self.leftExpression = self.leftExpression.list1

			#Now indexingNode not contains a list -> self.leftExpression.list1 is the VariableNode
			#add the leftmost index to the head of the index list
			indexList.insert(0, self.leftExpression.index.evaluate())

			#self.leftExpression.list1 now is the variableNode
			temp = self.leftExpression.list1.evaluate()

			for i in range(len(indexList)-1):
				temp = temp[indexList[i]]
				
			#Now temp is the last array we want to modify ->[1,2,3][4,5,6] -> [1,2,3]
			#we cannot get the cell directly because in that way we cannot modify it
			#change the data in the cell
			temp[indexList[len(indexList)-1]] = self.rightExpression.evaluate()

#for {} designed
class EmptyNode(Node):
	def __init__(self):
		pass
	def execute(self):
		pass


class PrintNode(Node):
	def __init__(self, v):
		self.v = v


	def execute(self):
		# if(isinstance(self.value, str)):
		# 	print("'"+self.value+"'")
		# else:
		# 	print(self.value)
		print(self.v.evaluate())

#ifnode
class IfNode(Node):
	def __init__(self, condition, block):
		self.condition = condition
		self.block = block

	def execute(self):
		if(self.condition.evaluate() == True):
			self.block.execute()


#ifelsenode
class IfElseNode(Node):
	def __init__(self, condition, ifBlock, elseBlock):
		self.condition = condition
		self.ifBlock = ifBlock
		self.elseBlock = elseBlock


	def execute(self):
		if(self.condition.evaluate() == True):
			self.ifBlock.execute()
		else:
			self.elseBlock.execute()

#ifelsenode
class WhileNode(Node):
	def __init__(self, condition, block):
		self.condition = condition
		self.block = block


	def execute(self):
		while(self.condition.evaluate() == True):
			self.block.execute()
			


#execute all the expressions in the expression list of the expressions node
#execute would call the execute method of all the nodes in the list
class BlockNode(Node):
	def __init__(self, n):

		#self.value would be a list of expressions
		self.nodeList = [n]

	def execute(self):
		for node in self.nodeList:
			node.execute()




###################






#Token identifiers section
tokens = (
	'LPAREN', 'RPAREN',
	'NUMBER', 'STRING',
	'PLUS','MINUS','TIMES','DIVIDE',
	'OR','AND','NOT','LESSTHAN','LESSEQUALTHAN','EQUAL','NOTEQUAL','GREATERTHAN',
	'GREATEREQUALTHAN','IN','FLOORDIVIDE','MODULUS','POWER','LBRACKET', 'RBRACKET',
	'COMMA','TRUE','FALSE',
	'ASSIGN','LEFTCURLY','RIGHTCURLY','SEMICOLON','PRINT','VARIABLE','IF','WHILE','ELSE'
	)


# Tokens' literal representation-> get a string, return the a token with same value
t_LPAREN  = r'\('
t_RPAREN  = r'\)'
t_PLUS    = r'\+'
t_MINUS   = r'-'
t_TIMES   = r'\*'
t_DIVIDE  = r'/'
t_LESSTHAN = r'<'
t_LESSEQUALTHAN = r'<='
t_EQUAL = r'=='
t_NOTEQUAL = r'<>'
t_GREATERTHAN = r'>'
t_GREATEREQUALTHAN = r'>='
t_FLOORDIVIDE = r'//'
t_MODULUS = r'%'
t_POWER = r'\*\*'
t_LBRACKET = r'\['
t_RBRACKET = r'\]'
t_COMMA = r','
t_ASSIGN = r'='
t_LEFTCURLY = r'\{'
t_RIGHTCURLY = r'\}'
t_SEMICOLON = r';'


#get a string, return a node contains that string instead of the original string
def t_NUMBER(t):
	r'-?\d*(\d\.|\.\d)\d* | \d+'
	try:
		t.value = NumberNode(t.value)
	except ValueError:
		print("Integer value too large %d", t.value)
		t.value = 0
	return t

def t_STRING(t):
	r'\'[^\']*\'|\"[^"]*\"'
	try:
		t.value = StringNode(t.value)
	except ValueError:
		print("String value is invalid %d", t.value)
		t.value = ""
	return t

def t_TRUE(t):
	r'True'
	try:
		t.value = BoolNode(t.value)
	except ValueError:
		print("Bool value is invalid %d", t.value)
		t.value = ""
	return t

def t_FALSE(t):
	r'False'
	try:
		t.value = BoolNode(t.value)
	except ValueError:
		print("Bool value is invalid %d", t.value)
		t.value = ""
	return t

#have higher priority than variable
def t_PRINT(t):
	r'print'
	return t

def t_IF(t):
	r'if'
	return t

def t_ELSE(t):
	r'else'
	return t

def t_WHILE(t):
	r'while'
	return t

def t_OR(t):
	r'or'
	return t

def t_AND(t):
	r'and'
	return t

def t_NOT(t):
	r'not'
	return t

def t_IN(t):
	r'in'
	return t


def t_VARIABLE(t):
	r'[A-Za-z][A-Za-z0-9_]*'
	try:
		t.value = VariableNode(t.value)
	except ValueError:
		print("Variable name is invalid %d", t.value)
		t.value = ""
	return t

# Ignored characters
t_ignore = " \t"

def t_error(t):
	global errorFlag
	errorFlag = 1
	print("SYNTAX ERROR1")
	

# Build the parser
import ply.lex as lex
parser = lex.lex()









# Parsing rules
precedence = (
	('left','OR'),
	('left','AND'),
	('left','NOT'),
	('left','LESSTHAN','LESSEQUALTHAN','EQUAL','NOTEQUAL','GREATERTHAN','GREATEREQUALTHAN'),
	('left', 'IN'),
	('left','PLUS','MINUS'),
	('left','FLOORDIVIDE'),
	('left','MODULUS'),
	('left','TIMES','DIVIDE'),
	('right','POWER'),
	('left','LBRACKET','RBRACKET'),
	('left','LPAREN','RPAREN'),
	)

#1
#block can contain any number of curly braces
def p_block_block(t):
	"""
	block : LEFTCURLY block RIGHTCURLY 
	"""
	t[0] = t[2]
#2
#block can be empty
def p_block_empty(t):
	"""
	block : LEFTCURLY RIGHTCURLY 
	"""
	t[0] = EmptyNode()
#3
#block can contain statements
def p_block_statements(t):
	"""
	block : LEFTCURLY statements RIGHTCURLY 
	"""
	t[0] = t[2]



#4
#statements can contain statement and statements
def p_statements_statement_statements(t):
	'''statements :  statement  statements '''

	t[0] = t[2]
	t[0].nodeList.insert(0,t[1])
#5
#statements can contain only one statement
def p_statements_statement(t):
	'''statements :  statement '''
				  
	t[0] = BlockNode(t[1])
#6
#statement can contain a block
def p_statement_block(t):
	"""
	statement : block 
	"""
	t[0] = t[1]
#7
#statment can be print statement
def p_statement_print_expression(t):
	"""
	statement : PRINT LPAREN expression RPAREN SEMICOLON
	"""
	t[0] = PrintNode(t[3])
#assignments
#8
#statement can be assignment statement
def p_variable_assign_expression(t):
	"""
	statement : expression ASSIGN expression SEMICOLON
	"""
	t[0] = AssignmentNode(t[1], t[3])
#conditional
#9
#statement can be if statement
def p_statement_if(t):
	"""
	statement : IF LPAREN expression RPAREN block 
	"""
	t[0] = IfNode(t[3], t[5])
#10
#statement can be if else statement
def p_statement_if_else(t):
	"""
	statement : IF LPAREN expression RPAREN block ELSE block
	"""
	t[0] = IfElseNode(t[3], t[5],t[7])
#11
#statement can be hile statement
def p_statement_while(t):
	"""
	statement : WHILE LPAREN expression RPAREN block 
	"""
	t[0] = WhileNode(t[3], t[5])








#12,13,14,15
def p_expression_binop(t):
	'''expression : expression PLUS expression
				  | expression MINUS expression
				  | expression TIMES expression
				  | expression DIVIDE expression
				  | expression FLOORDIVIDE expression
				  | expression MODULUS expression'''

	t[0] = BopNode(t[2], t[1], t[3])

#16
def p_expression_powerOp(t):
	'''expression : expression POWER expression'''

	t[0] = PowerNode(t[1], t[3])


#17
def p_expression_parent(t):
	'''expression : LPAREN expression RPAREN'''
				  
	t[0] = t[2]

#18
def p_expression_list(t):
	'''expression : LBRACKET list RBRACKET'''
				  
	t[0] = t[2]

#19
def p_expression_emptyList(t):
	'''expression : LBRACKET RBRACKET'''
				  
	t[0] = EmptyListNode()

#20
def p_expression_list_indexing(t):
	'''expression : expression LBRACKET expression RBRACKET'''
				  
	t[0] = IndexingNode(t[1],t[3])

#21,22,23,24
def p_expression_booleanOp(t):
	'''expression : expression OR expression
				  | expression AND expression
				  | expression LESSTHAN expression
				  | expression LESSEQUALTHAN expression
				  | expression EQUAL expression
				  | expression NOTEQUAL expression
				  | expression GREATERTHAN expression
				  | expression GREATEREQUALTHAN expression
				  | expression IN expression'''
	t[0] = BooleanNode(t[2], t[1], t[3])

#25
def p_expression_notOp(t):
	'''expression : NOT expression'''
	t[0] = NotNode(t[2])









#26 I remove the comma by -> in tokenizing part, if i detect comma, i return nothing
#from right to left, we always have last element added to the list first
#e.g. list-> ex list-> ex ex list -> ex ex ex ex list-> 
#       ex ex ex ex -> ex ex ex list -> ex ex list -> ex list -> list
def p_list_expression_list(t):
	'''list :  expression COMMA list '''

	t[0] = t[3]
	t[0].list1.insert(0,t[1])

#27 #if there are more than 1 elements, 14 will run the first
def p_list_expression(t):
	'''list :  expression '''
				  
	t[0] = ListNode(t[1])



#28
def p_expression_factor(t):
	'''expression : factor'''
	t[0] = t[1]


#29
def p_factor_number(t):
	'''factor : NUMBER
			  | STRING  
			  | TRUE
			  | FALSE
			  | VARIABLE'''
	t[0] = t[1]



def p_error(t):
	print("SYNTAX ERROR")
	global errorFlag
	errorFlag = 1
	#parser.token()
	raise SyntaxError



import ply.yacc as yacc
yacc.yacc()

import sys

def main():
	
	global errorFlag

	if (len(sys.argv) != 2):
	   sys.exit("invalid arguments")
	fd = open(sys.argv[1], 'r')

	#collect all the codes into one block
	code = ""
	for line in fd:
		code += line.strip()

	#input collected code into lex
	try:
		lex.input(code)
		while True:
			token = lex.token()
			if not token: 
				break
				
			#print(token)
		#print("=========================================")
		ast = yacc.parse(code)
		ast.execute()
		
		
	except Exception:
		if(errorFlag == 0):
			print("SEMANTIC ERROR")


	#print (variables)
	errorFlag = 0

		

main()
